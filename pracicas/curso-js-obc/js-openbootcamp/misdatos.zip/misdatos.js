const miNombre = "Lucas";
var edad = 22;
var iAmDeveloper = true;
const birthday= new Date ("july 2 1999");
const libroFavorito = {
    titulo: "Como hacer amigos e influir en las personas",
    autor: "Dale Carnegie",
    fecha: new Date ("1936"),
    url: "www.libroloco.com/dc"
}
console.log(miNombre);
console.log(edad);
console.log(iAmDeveloper);
console.log(birthday);
console.log(libroFavorito);